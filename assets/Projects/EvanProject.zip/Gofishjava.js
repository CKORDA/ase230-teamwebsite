const deck = [
    'ace of hearts', '2 of hearts', '3 of hearts', '4 of hearts', '5 of hearts', '6 of hearts', '7 of hearts', '8 of hearts',
    '9 of hearts', '10 of hearts', 'Jack of hearts', 'Queen of hearts', 'King of hearts',
    'ace of spades', '2 of spades', '3 of spades', '4 of spades', '5 of spades', '6 of spades', '7 of spades', '8 of spades',
    '9 of spades', '10 of spades', 'Jack of spades', 'Queen of spades', 'King of spades',
    'ace of clubs', '2 of clubs', '3 of clubs', '4 of clubs', '5 of clubs', '6 of clubs', '7 of clubs', '8 of clubs',
    '9 of clubs', '10 of clubs', 'Jack of clubs', 'Queen of clubs', 'King of clubs',
    'ace of diamonds', '2 of diamonds', '3 of diamonds', '4 of diamonds', '5 of diamonds', '6 of diamonds', '7 of diamonds', '8 of clubs',
    '9 of diamonds', '10 of diamonds', 'Jack of diamonds', 'Queen of diamonds', 'King of diamonds'];

//Matches
let pMatches = 0;
let oMatches = 0;
let game = true;

let pHand = [];
let oHand = [];


//
function cardPhys(card) {
}
function displayImage(src, width, height) {
    var img = document.createElement("img");
    img.src = src;
    img.width = width;
    img.height = height;
    document.body.appendChild(img);
}

function display() {
    pShowMatches();
    oShowMatches();
    ShowHand();
}

function pShowMatches() {
    document.getElementById("pOutput").innerHTML = pMatches;
}
function oShowMatches() {
    document.getElementById("oOutput").innerHTML = oMatches;
}
function ShowHand() {
    //let x = [...pHand]
    //for(let i = 0; i < x.length; i++) {
    //    x[i] = displayImage("rockpaperscissors.jpg", 100, 100);
    //}
    //document.getElementById("hand").innerHTML = x;

    document.getElementById("hand").innerHTML = pHand;
}

function drawCards(target) {
    if(deck.length > 0) {
        let x = ranCard();
        target.push(deck[x]);
        deck.splice(x, 1);
    }
    else {
        // look at later
        checkWinner();
    }
}

function ranCard() {
    return Math.floor(Math.random() * (deck.length));    
}

//draws cards for each player and asks for input
function startGame() {
    for (let i = 0; i < 7; i++) {
        drawCards(pHand);
        drawCards(oHand);
    }
    display();
    alert(pHand);
    pCheckMatches();
    oCheckMatches();
    display();
    if(pMatches > 1) {
        alert("There were " + pMatches + " matches in your hand");
    }
    else if(pMatches == 1) {
        alert("There was 1 match in your hand");
    }
    else {
        alert("There were no matches in your hand");
    }
    display();
}

//returns the value without the suit
function cardVal(card) {
    let x = '';
    for(let i = 0; i < card.length; i++){
        if(card.charAt(i) != ' ') {
            x += card.charAt(i)
        }
        else {
            return x
        }
    }
}

function pInHand(card) {
    for(let i = 0; i < pHand.length; i++) {
        if(cardVal(pHand[i]) == card) {
            return [true, pHand[i]];
        }
    }
    return false;
}

function oInHand(card) {
    for(let i = 0; i < oHand.length; i++) {
        if(oHand[i] == card) {
            return true;
        }
    }
    return false
}

function pCheckMatches() {
    let x = '';
    let y = '';
    let z = 0;
    for(let i = 0; i < pHand.length; i++) {
        for(let j = 0; j < pHand.length; j++) {
            if(i != j) {
                if(cardVal(pHand[i]) == cardVal(pHand[j])) {
                    x = pHand[i];
                    y = pHand[j];
                    console.log(pHand.splice(pHand.indexOf(x), 1) + " pTurn: card1 match");
                    console.log(pHand.splice(pHand.indexOf(y), 1) + " pTurn: card2 match");
                    pMatches += 1;
                    z += 1
                }
            }   
        }
    }
    return z;
}

function oCheckMatches() {
    let x = '';
    let y = '';
    for(let i = 0; i < oHand.length; i++) {
        for(let j = 0; j < oHand.length; j++) {
            if(i != j) {
                if(cardVal(oHand[i]) == cardVal(oHand[j])) {
                    x = oHand[i];
                    y = oHand[j];
                    console.log(oHand.splice(oHand.indexOf(x), 1) + " oTurn: card1 match");
                    console.log(oHand.splice(oHand.indexOf(y), 1) + " oTurn: card2 match");
                    oMatches += 1;
                }
            }   
        }
    }
}

//user asks opponent for a card
function pTurn(card) {
    if(game == true) {
        let card1 = pInHand(card);
        if(card1[0]) {
            let x = false;
            for(let i = 0; i < oHand.length; i++) {
                if(cardVal(oHand[i]) == card) {
                    x = true;
                    console.log(pHand.splice(pHand.indexOf(card1[1]), 1) + " pTurn: player's card");
                    console.log(oHand.splice(i, 1) + " pTurn: opponent's card");
                    //pHand.splice(pHand.indexOf(card), 1);
                    //oHand.splice(i, 1);
                }
            }
            if(x == true) {
                pMatches += 1;
                alert("MATCH!");
                display();
                checkWinner();
            }
            else {
                drawCards(pHand);
                display();
                if (cardVal(pHand[pHand.length - 1]) == 8 || cardVal(pHand[pHand.length - 1]) == 'ace') {
                    alert("Go Fish! You drew an " + pHand[pHand.length - 1] + ".");
                }
                else {
                    alert("Go Fish! You drew a " + pHand[pHand.length - 1] + ".");
                }
                if(pCheckMatches() > 0) {
                    alert("You got a match");
                }
                display();
                if(game == true) {
                    oTurn();
                }
                display();
                checkWinner();
            }
        }
        else {
            alert("Not in hand");
        }
    }
    else {
        checkWinner()
    }
}

function oTurn() {
    checkWinner();
    const card = oHand[Math.floor(Math.random() * (oHand.length))];
    let x = false;
    for(let i = 0; i < pHand.length; i++) {
        if(cardVal(pHand[i]) == cardVal(card)) {
            x = true;
            console.log(oHand.splice(oHand.indexOf(card), 1) + " oTurn: opponent's card");
            console.log(pHand.splice(i, 1) + " oTurn: player's card");
        }
    }
    if(x == true) {
        oMatches += 1;
        alert("Opponent chooses " + card + ", MATCH!");
        oTurn(); //second turn for getting a match
    }
    else {
        drawCards(oHand);
        alert("Opponent chooses " + card + ", Go Fish!");
        oCheckMatches();
    }
}

//Win conditions
function checkWinner() {
    if(oHand.length > 0 && pHand.length > 0 && deck.length) {
        if(pMatches == 13) {
            alert('Player Wins! Refresh the page to play again');
            game = false;
            return "pWins";
        }
        else if(oMatches == 13) {
            alert('Opponent Wins! Refresh the page to play again');
            game = false;
            return "oWins";
        }
        else {}
    }
    else if(deck.length == 0) {
        alert("Deck ran out of cards");
        if(pMatches > oMatches) {
            alert('Player Wins! Refresh the page to play again');
            game = false;
            return "pWins";
        }
        else if(oMatches > pMatches){
            alert('Opponent Wins! Refresh the page to play again');
            game = false;
            return "oWins";
        }
        else {
            alert("Tie. Refresh the page to play again");
            game = false;
        }
    }
    else if(oHand.length == 0) {
        alert("Opponent ran out of cards");
        if(pMatches > oMatches) {
            alert('Player Wins! Refresh the page to play again');
            game = false;
            return "pWins";
        }
        else if(oMatches > pMatches){
            alert('Opponent Wins! Refresh the page to play again');
            game = false;
            return "oWins";
        }
        else {
            alert("Tie. Refresh the page to play again");
            game = false;
        }
    }
    else if(pHand.length == 0) {
        alert("You ran out of cards");
        if(pMatches > oMatches) {
            alert('Player Wins! Refresh the page to play again');
            game = false;
            return "pWins";
        }
        else if(oMatches > pMatches){
            alert('Opponent Wins! Refresh the page to play again');
            game = false;
            return "oWins";
        }
        else {
            alert("Tie. Refresh the page to play again");
            game = false;
        }
    }
    else {}
}

