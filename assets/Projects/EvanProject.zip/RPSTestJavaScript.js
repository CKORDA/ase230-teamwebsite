//
function myfunction(){
    // Setting DOM to all boxes or input field
    var rock, paper, scissors;
    rock = document.getElementById("rock").value;
    paper = document.getElementById("paper").value;
    scissors = document.getElementById("scissors").value;
    //Computer generated choice:
    var compchoice = Math.floor(Math.random()*3);
    //Possible outcomes based on your choise and then the computers choice.
    if(document.getElementById("rock").value == "X"){
        if(compchoice==0){
            alert("You chose rock,and the computer chose rock.\nIt's a tie!");
        }else if(compchoice==1){
            alert("You chose rock,and the computer chose paper.\nYou lost.");
        }else if(compchoice==2){
            alert("You chose rock,and the computer chose scissors.\nYou won!");
        }
    }else if(document.getElementById("paper").value == "X"){
        if(compchoice==0){
            alert("You chose paper,and the computer chose rock.\nYou won!");
        }else if(compchoice==1){
            alert("You chose paper,and the computer chose paper.\nIt's a tie!");
        }else if(compchoice==2){
            alert("You chose paper,and the computer chose scissors.\nYou lost.");    
        }
    }else if(document.getElementById("scissors").value == "X"){
        if(compchoice==0){
            alert("You chose scissors,and the computer chose rock.\nYou lost.");
        }else if(compchoice==1){
            alert("You chose scissors,and the computer chose paper.\nYou won!");
        }else if(compchoice==2){
            alert("You chose scissors,and the computer chose scissors.\n It's a tie!");
        }
    }
}
// Function to reset game
function myfunc_2() {
    location.reload();
    document.getElementById('rock').value = '';
    document.getElementById("paper").value = '';
    document.getElementById("scissors").value = '';
  
}

function rockfunc(){
    document.getElementById('rock').value = "X";
    document.getElementById('rock').disabled = true;
}

function paperfunc(){
    document.getElementById('paper').value = "X";
    document.getElementById('paper').disabled = true;
}

function scissorsfunc(){
    document.getElementById('scissors').value = "X";
    document.getElementById('scissors').disabled = true;
}