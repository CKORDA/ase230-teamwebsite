let categories = [
	{"name":"Books","id":"1"},
	{"name":"Music","id":"2"},
	{"name":"Games","id":"3"},
	{"name":"Shoes","id":"4"},
	{"name":"Furniture","id":"5"}
];

let items = [
 {
  "createdAt": "2022-10-28T19:38:40.770Z",
  "productId": "90ec1be1-7e12-42c0-abb8-858fc6e15e14",
  "itemName": "Portable eBook Reader",
  "itemBrief": "Read your heart out with this awesome portable eBook reader",
  "itemFull": "Ullam ut maiores voluptates rerum. Voluptates molestiae quos et atque ducimus ipsa ea culpa molestiae. Praesentium voluptas illum rerum soluta a architecto. Soluta rerum commodi aut quo voluptatem facere. Quidem non ipsum. Eaque alias et omnis laudantium et consequuntur.\nFacere dolorem numquam a fuga omnis. Cum enim occaecati perferendis quidem omnis. Quidem corporis quaerat quas deserunt ullam et magnam. Dolor quidem et ea earum inventore corporis voluptatem dolorem nesciunt. Est sit mollitia laboriosam beatae. Laboriosam provident illum a optio saepe architecto eaque.\nAlias aut et et ipsam. Qui omnis debitis qui ut iusto. Doloribus tempora qui omnis nihil eum nihil doloribus. Ratione odio excepturi et eius. Laborum modi natus dolores ea atque veniam. A voluptatem neque qui rem voluptates dolore.",
  "price": "899.00",
  "size": [
   "Room for 5 books",
   "Room for 15 books",
   "Room for 50 books",
   "Room for 500 books",
   "Room for 5000 books"
  ],
  "colors": [
   "Silver"
  ],
  "image": [
   "https://picsum.photos/id/1/800/600",
   "https://picsum.photos/id/2/800/600",
   "https://picsum.photos/id/3/800/600",
   "https://picsum.photos/id/4/800/600"
  ],
  "itemId": "1",
  "categoryId": "1"
 },
 {
  "createdAt": "2022-10-28T04:56:17.343Z",
  "productId": "08926d01-213f-447c-a79a-b56bbbe3d96c",
  "itemName": "Elegant Concrete Table",
  "itemBrief": "The Apollotech B340 is an affordable wireless mouse with reliable connectivity, 12 months battery life and modern design",
  "itemFull": "Enim aut omnis eaque quia aliquam laborum eaque laborum. Sunt nesciunt nemo nulla quisquam iste aut dicta. Eos distinctio est voluptas vitae magnam quis. Vel reprehenderit aliquam deleniti tempora rerum quod.\nNesciunt aut in nihil aut debitis. Fugiat sapiente et consequatur ea vel repellendus suscipit quas aliquid. Quia maiores velit quis facere unde et architecto voluptatum. Ratione corrupti voluptas eum vitae. Et rem quia ipsa. Magnam dolorum in fugit sequi ducimus nisi asperiores qui dolore.\nMolestiae in velit aut est. Ab et nam aut. Deleniti quasi harum labore voluptate et magni molestiae. Placeat et qui laborum quae nemo. Qui est officia ipsum.",
  "price": "523.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "ivory",
   "azure",
   "red",
   "salmon",
   "indigo"
  ],
  "image": [
   "https://picsum.photos/id/1082/800/600",
   "https://picsum.photos/id/6/800/600",
   "https://picsum.photos/id/7/800/600",
   "https://picsum.photos/id/8/800/600"
  ],
  "itemId": "2",
  "categoryId": "2"
 },
 {
  "createdAt": "2022-10-28T00:21:09.999Z",
  "productId": "3cc04258-6fee-4771-9196-40a584931271",
  "itemName": "Bloody Digits Game",
  "itemBrief": "Laugh it up with friends and family as they loose fingers, toes and more with the hit hand-on (or hands off!) game, Bloody Digits!",
  "itemFull": "Sit deserunt voluptatum aspernatur. Sint et quae qui ut illo. Quidem sit corrupti sint laudantium est. Qui labore enim soluta et praesentium. Reiciendis odit et molestiae.\nAut modi id aut. Repudiandae beatae asperiores quaerat. Natus quia quod quibusdam mollitia ea totam aut dolor sed.\nVel nemo accusantium optio et veniam ut rerum sapiente et. Quisquam repudiandae accusamus qui adipisci esse itaque nisi cum placeat. Est maiores dolorem optio esse mollitia repellat corrupti maxime voluptatum. Reiciendis officia qui eveniet ullam hic vel. Laborum voluptatem et. Excepturi deserunt accusantium incidunt labore aut expedita ut.",
  "price": "230.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "maroon",
   "grey",
   "orchid",
   "lavender",
   "red"
  ],
  "image": [
   "https://picsum.photos/id/491/800/600",
   "https://picsum.photos/id/10/800/600",
   "https://picsum.photos/id/11/800/600",
   "https://picsum.photos/id/12/800/600"
  ],
  "itemId": "3",
  "categoryId": "3"
 },
 {
  "createdAt": "2022-10-28T11:43:32.998Z",
  "productId": "ee06da54-769b-45d7-9cd6-eb77d8e3286a",
  "itemName": "Recycled White Shoes",
  "itemBrief": "Boston's most advanced compression wear technology increases foot comfort, stabilizes active muscles",
  "itemFull": "Et laboriosam quam occaecati voluptas molestias id qui. Quia error minima ea maiores. Consequatur voluptatibus voluptate non porro est.\nSoluta iste voluptatum in beatae maxime. Est fugit possimus sit omnis suscipit. Consequatur voluptatibus at eum. Enim numquam occaecati. Eum sit sint ea aut nihil alias repudiandae sit ullam.\nVoluptatum harum ipsum. Deserunt fugit et non et. Dicta dolores vel iusto ut debitis excepturi aut quia laborum.",
  "price": "732.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "black",
   "black",
   "sky blue",
   "black",
   "black"
  ],
  "image": [
   "https://picsum.photos/id/21/800/600",
   "https://picsum.photos/id/22/800/600",
   "https://picsum.photos/id/23/800/600",
   "https://picsum.photos/id/24/800/600"
  ],
  "itemId": "4",
  "categoryId": "4"
 },
 {
  "createdAt": "2022-10-28T00:26:15.197Z",
  "productId": "9ddf7969-79d2-4226-843f-f9b532ca119d",
  "itemName": "Desk With Sleek Mat",
  "itemBrief": "Ergonomic desk with sleek cancer-causing PVC mat for all-day comfort and support",
  "itemFull": "Dolore sequi quae voluptatem. Illo ut non labore quia et. Fugiat qui consequatur reprehenderit. Dicta ratione reiciendis aut voluptates sit vel molestias modi. Dignissimos at atque necessitatibus.\nQuia ea nam maxime sunt velit ut. Labore aut et corrupti accusamus vero officia debitis ut. Qui sint rem aspernatur. Delectus debitis nesciunt in quibusdam.\nOfficia aliquam odio. Voluptatem quis quia facilis magnam soluta et impedit nostrum. Perspiciatis nesciunt adipisci rem ducimus soluta est optio quas.",
  "price": "965.00",
  "size": [
   "60x36 inches"
  ],
  "colors": [
   "blond maple",
   "dark brown mahogany",
   "rich red cherry"
  ],
  "image": [
   "https://picsum.photos/id/445/800/600",
   "https://picsum.photos/id/18/800/600",
   "https://picsum.photos/id/19/800/600",
   "https://picsum.photos/id/20/800/600"
  ],
  "itemId": "5",
  "categoryId": "5"
 },
 {
  "createdAt": "2022-10-28T08:30:20.489Z",
  "productId": "ba95fdda-fd0b-496f-a6cd-07164f91f5ec",
  "itemName": "Gorgeous Old Book",
  "itemBrief": "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit",
  "itemFull": "Error saepe sed voluptatum quod nostrum sit doloribus sunt. Perspiciatis sint voluptas quia consequuntur molestiae aut qui ab qui. Aut omnis nobis soluta a nisi in fuga totam. Culpa eos doloremque non nisi. Ea vero repellendus vitae sed.\nUt et architecto neque et excepturi ut provident ut. Voluptatem adipisci soluta quia. Quibusdam quo quos itaque. Voluptates modi commodi. Rerum quaerat accusantium omnis voluptatum sed nemo numquam.\nNecessitatibus distinctio quisquam sed et perspiciatis. Vel illum ipsum corporis voluptas. Magni accusantium nulla. Autem praesentium iusto repellendus explicabo in iure est. Eius repudiandae sit.",
  "price": "26.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "green",
   "plum",
   "turquoise",
   "yellow",
   "silver"
  ],
  "image": [
   "https://picsum.photos/id/1010/800/600",
   "https://picsum.photos/id/14/800/600",
   "https://picsum.photos/id/15/800/600",
   "https://picsum.photos/id/16/800/600"
  ],
  "itemId": "6",
  "categoryId": "1"
 },
 {
  "createdAt": "2022-10-28T16:03:09.725Z",
  "productId": "891fc0c3-a0b5-4a0c-9b12-2d96ac74915a",
  "itemName": "Electronic Metal Table",
  "itemBrief": "The automobile layout consists of a front-engine design, with transaxle-type transmissions mounted at the rear of the engine and four wheel drive",
  "itemFull": "Nihil sequi sint doloribus. Et consectetur nostrum suscipit officiis ut sunt aut vel. Odit est cupiditate illum maiores non. Ipsam unde quod id repudiandae. Labore sed non perferendis dolores culpa dolore. Consectetur voluptatem commodi voluptate atque aut quae dicta enim.\nSint et aut sit molestias aliquam vel facilis corporis. Et quidem quod. Accusamus cumque molestiae in perferendis ut quas laborum. Autem accusantium sunt ducimus et consequatur officia voluptatum placeat asperiores. In ea nobis. Repellat numquam sunt esse nihil non.\nQuibusdam qui vel eos qui tempora. Nostrum quod dolor porro sequi perferendis. Nam culpa maxime est beatae autem totam. Aut omnis quisquam autem dolores consequatur enim est eius facere. Quia ut molestiae aperiam consequatur sed eaque voluptas enim.",
  "price": "831.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "fuchsia",
   "green",
   "red",
   "gold",
   "pink"
  ],
  "image": [
   "https://picsum.photos/id/145/800/600",
   "https://picsum.photos/id/26/800/600",
   "https://picsum.photos/id/27/800/600",
   "https://picsum.photos/id/28/800/600"
  ],
  "itemId": "7",
  "categoryId": "2"
 },
 {
  "createdAt": "2022-10-28T07:06:11.450Z",
  "productId": "6933f8bc-5096-4976-ba49-86ac8bfbb38a",
  "itemName": "Dead Mouse in a Cup Game",
  "itemBrief": "This sleek, mass-produced coffee cup will thrill you endlessly as it attracts rodents who playfully kiss and nip you on the lips, reminding you that hot coffee is an uncomfortable for them.",
  "itemFull": "Mollitia ut et dolorem rerum nesciunt cupiditate in velit. Et et deleniti sed deserunt porro et minima. Ut soluta aut numquam ipsa iure explicabo.\nNam sed impedit vel eos. Eaque sit et. Praesentium rerum nemo non corporis repudiandae fugiat.\nAut autem aut quis blanditiis non assumenda accusantium in. Aspernatur quidem hic. Magni ad qui expedita fuga quia. A fugiat tempora cumque sed possimus officia. Adipisci soluta et sunt nam sed adipisci.",
  "price": "18.00",
  "size": [
   "Cup only",
   "Cup with mouse",
   "Cup with pregnant mouse"
  ],
  "colors": [
   "cyan",
   "pink",
   "turquoise",
   "orange",
   "pink"
  ],
  "image": [
   "https://picsum.photos/id/30/800/600",
   "https://picsum.photos/id/31/800/600",
   "https://picsum.photos/id/32/800/600",
   "https://picsum.photos/id/33/800/600"
  ],
  "itemId": "8",
  "categoryId": "3"
 },
 {
  "createdAt": "2022-10-28T17:53:14.569Z",
  "productId": "f82e95b8-9603-4635-924b-f8a4f2601b1b",
  "itemName": "Retro Canvas Hightops",
  "itemBrief": "Andy shoes are designed to keeping in mind durability as well as trends, the most stylish range of shoes & sandals",
  "itemFull": "Et cum sit quasi voluptas nesciunt quia dolorum reiciendis sunt. Quisquam mollitia ducimus tenetur. Incidunt quos non eaque tempora. Dolores hic sit dolorem laborum quasi vel.\nDolor eos sint assumenda in hic. Laborum necessitatibus mollitia alias aspernatur. Velit ab voluptates quisquam adipisci dolorem.\nAperiam corrupti ut vel voluptatem rerum qui. Ex ipsum accusantium eaque optio sit est a tempore quaerat. Aperiam id accusamus qui voluptas voluptatem dolores eveniet sapiente. Incidunt praesentium quaerat quia at fugiat sit.",
  "price": "456.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "turquoise",
   "cyan",
   "red",
   "fuchsia",
   "magenta"
  ],
  "image": [
   "https://picsum.photos/id/103/800/600",
   "https://picsum.photos/id/35/800/600",
   "https://picsum.photos/id/36/800/600",
   "https://picsum.photos/id/37/800/600"
  ],
  "itemId": "9",
  "categoryId": "4"
 },
 {
  "createdAt": "2022-10-27T23:16:48.864Z",
  "productId": "6698ffde-fef9-45a7-93c2-bd30553fe788",
  "itemName": "Leaf Attracting Bench",
  "itemBrief": "You'll never sit on a clean seat again with these beautiful leaf-attracting benches",
  "itemFull": "Rerum ut doloremque. Aut nesciunt dolores. Perferendis quasi rem est et. Atque doloribus ipsum provident. Nobis et molestiae et at. Cupiditate nemo repellat natus nihil eligendi.\nNon perspiciatis ut inventore recusandae minima illo officia. Nihil harum quasi et maxime nihil nesciunt architecto et. Corporis magnam dolorem expedita voluptatem enim nisi non. Deleniti nisi enim quia quae omnis.\nAut fuga et. Dicta eligendi dolore voluptatum optio. Quis fugiat consequuntur dolores atque laborum asperiores nesciunt. Ipsum qui maiores nulla. Non totam quia quos accusamus laborum omnis saepe.",
  "price": "159.00",
  "size": [
   "2 persons",
   "3 persons",
   "2 persons and support hedgehog"
  ],
  "colors": [
   "weathered gray",
   "not yet weathered gray"
  ],
  "image": [
   "https://picsum.photos/id/553/800/600",
   "https://picsum.photos/id/39/800/600",
   "https://picsum.photos/id/40/800/600",
   "https://picsum.photos/id/41/800/600"
  ],
  "itemId": "10",
  "categoryId": "5"
 },
 {
  "createdAt": "2022-10-28T13:21:55.808Z",
  "productId": "2501a7a7-3f1b-4cf7-8e8e-48adeaf12809",
  "itemName": "Gorgeous Fresh Car",
  "itemBrief": "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit",
  "itemFull": "Et iure rerum officia occaecati quidem eius consequatur. Maiores sapiente quas. Laboriosam harum et. Qui cum tempore. Quisquam nemo dignissimos sequi.\nMagnam nobis adipisci doloribus quo. Quae nisi dolores voluptates itaque. A quo sint voluptatibus autem qui fuga. Assumenda blanditiis sint ducimus magni possimus iure.\nEt vel voluptate iusto possimus quia eos voluptate dicta. Illum eligendi doloremque ut et cumque ipsum unde. Ut earum dolorem sit voluptate nemo et blanditiis dolore et. Neque excepturi est.",
  "price": "711.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "orchid",
   "orchid",
   "orange",
   "magenta",
   "silver"
  ],
  "image": [
   "https://picsum.photos/id/42/800/600",
   "https://picsum.photos/id/43/800/600",
   "https://picsum.photos/id/44/800/600",
   "https://picsum.photos/id/45/800/600"
  ],
  "itemId": "11",
  "categoryId": "1"
 },
 {
  "createdAt": "2022-10-28T13:29:49.909Z",
  "productId": "b73975a9-bc7b-4b7b-9d47-3114a0d4fab5",
  "itemName": "Tasty Bronze Pizza",
  "itemBrief": "The slim & simple Maple Gaming Keyboard from Dev Byte comes with a sleek body and 7- Color RGB LED Back-lighting for smart functionality",
  "itemFull": "A dolores doloremque necessitatibus et voluptatem deserunt facilis atque rerum. Maiores velit qui. Ea et error quo soluta ducimus eligendi.\nDoloremque quo laboriosam consequatur. Nobis debitis voluptatem in omnis enim nam deleniti occaecati. Id aliquid natus accusantium sit necessitatibus et numquam nihil. Magnam omnis eos perferendis velit vero nulla at omnis.\nSit hic porro rem ut est dolor quae repudiandae. Quod dolores accusantium commodi quia quia deleniti ut quia est. Dolores laborum provident quam iusto rerum distinctio repudiandae quo. Aut earum nostrum dolorem fugit. Ut quis libero vero minus voluptatem.",
  "price": "361.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "lavender",
   "orange",
   "silver",
   "maroon",
   "red"
  ],
  "image": [
   "https://picsum.photos/id/46/800/600",
   "https://picsum.photos/id/47/800/600",
   "https://picsum.photos/id/48/800/600",
   "https://picsum.photos/id/49/800/600"
  ],
  "itemId": "12",
  "categoryId": "2"
 },
 {
  "createdAt": "2022-10-28T01:47:37.680Z",
  "productId": "f00dd6b9-3b10-4e04-9870-3097355a2bdb",
  "itemName": "Handmade Frozen Tuna",
  "itemBrief": "The beautiful range of Apple Naturalé that has an exciting mix of natural ingredients. With the Goodness of 100% Natural Ingredients",
  "itemFull": "Maiores in in id aliquam. Quae et sed consequatur qui laborum. Libero necessitatibus reprehenderit voluptatibus eos non aut nobis. Esse voluptas qui nobis quia porro inventore. Accusantium minus dolorum porro dolor eos non dolor optio officia. Ipsa dolores ut.\nQuos praesentium dolores impedit minus doloremque molestiae tenetur rerum. Ea perferendis ratione minus. Est et veritatis in. Quasi ab fugit sunt quisquam ea voluptatem ut neque.\nQui eos suscipit et. Eveniet et fugiat aut eum perferendis. Sint laudantium quia cupiditate inventore excepturi quasi labore maxime praesentium. Exercitationem aut perspiciatis qui et mollitia. Accusantium impedit earum quo vitae minus quibusdam ipsam quasi excepturi. Officiis facilis unde tenetur voluptatum laborum laborum.",
  "price": "495.00",
  "size": [
   "XL",
   "XXL"
  ],
  "colors": [
   "green",
   "indigo",
   "red",
   "gold",
   "lavender"
  ],
  "image": [
   "https://picsum.photos/id/50/800/600",
   "https://picsum.photos/id/51/800/600",
   "https://picsum.photos/id/52/800/600",
   "https://picsum.photos/id/53/800/600"
  ],
  "itemId": "13",
  "categoryId": "3"
 },
 {
  "createdAt": "2022-10-28T06:54:08.811Z",
  "productId": "98ca714b-6569-41ec-8f4f-4ed0a42501b8",
  "itemName": "Incredible Granite Keyboard",
  "itemBrief": "The Nagasaki Lander is the trademarked name of several series of Nagasaki sport bikes, that started with the 1984 ABC800J",
  "itemFull": "Tempora distinctio ad modi provident dolorum voluptate odit ut aspernatur. Est quo fugiat reiciendis consequuntur maiores. Impedit error fuga velit beatae illo. Numquam modi rem deleniti nisi.\nQuidem cupiditate id quos vero optio numquam assumenda. Enim accusantium dignissimos facilis occaecati quia exercitationem quis voluptatem ab. Maxime assumenda iste quae in molestiae ipsa sint veniam. Ab adipisci excepturi voluptas nobis commodi animi perferendis. Animi dolores voluptatem aut suscipit. Non nihil vel ipsum voluptates pariatur et.\nEt quaerat amet in quos minima similique dolorem. Nostrum a modi et omnis corporis eos assumenda. Autem aut est maxime sed et laborum dolores quidem. Ea saepe unde recusandae nisi suscipit at et. Corrupti dolorem voluptas dolorem facilis eum. Reiciendis voluptas qui autem alias.",
  "price": "800.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "gold",
   "gold",
   "olive",
   "teal",
   "ivory"
  ],
  "image": [
   "https://picsum.photos/id/54/800/600",
   "https://picsum.photos/id/55/800/600",
   "https://picsum.photos/id/56/800/600",
   "https://picsum.photos/id/57/800/600"
  ],
  "itemId": "14",
  "categoryId": "4"
 },
 {
  "createdAt": "2022-10-28T18:56:02.347Z",
  "productId": "e96a4b88-8a38-4a1e-946f-ec1d1eb2420b",
  "itemName": "Refined Fresh Hat",
  "itemBrief": "Boston's most advanced compression wear technology increases muscle oxygenation, stabilizes active muscles",
  "itemFull": "Atque qui ex voluptate. Modi suscipit occaecati. Nam vel quia quod qui et ipsum porro reprehenderit.\nEst repellendus nihil aliquam quia blanditiis enim qui. Voluptatem ducimus magni quia officia magnam odio incidunt labore. Sapiente ipsam commodi in incidunt voluptates. Eum ut iste voluptatem ut corrupti voluptatibus. Rerum quae et commodi doloribus omnis et magni officiis. Ut a laborum aperiam aut laborum tempora voluptas.\nConsectetur minima dolor et saepe possimus. Deleniti dignissimos cum aspernatur nihil eum non magni ut in. Sed sit dolores asperiores recusandae. Ipsam repellat quia quia saepe. Quibusdam enim iusto quia veniam illum dolorem delectus. Molestiae qui fugit quam dignissimos qui adipisci.",
  "price": "921.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "indigo",
   "mint green",
   "grey",
   "indigo",
   "pink"
  ],
  "image": [
   "https://picsum.photos/id/58/800/600",
   "https://picsum.photos/id/59/800/600",
   "https://picsum.photos/id/60/800/600",
   "https://picsum.photos/id/61/800/600"
  ],
  "itemId": "15",
  "categoryId": "5"
 },
 {
  "createdAt": "2022-10-28T03:46:35.658Z",
  "productId": "e6bf3d49-1f65-44fa-9354-8a9716505880",
  "itemName": "Intelligent Steel Chair",
  "itemBrief": "The automobile layout consists of a front-engine design, with transaxle-type transmissions mounted at the rear of the engine and four wheel drive",
  "itemFull": "Aut illo eveniet provident maxime. Deleniti ab dicta placeat ut similique maxime. Expedita pariatur optio.\nIpsum repellendus error et culpa voluptas exercitationem. Ipsa omnis sed vel error ut tempora vel odio. Et et rerum. Beatae possimus animi in dicta. Placeat quam dolores. Beatae at hic quo qui eius qui.\nEt sed aliquid. Quisquam nihil culpa rem sed pariatur. Libero quia quia ad sed. Sed perspiciatis officiis ad nisi qui consequuntur sint non.",
  "price": "83.00",
  "size": [
   "S",
   "M",
   "L"
  ],
  "colors": [
   "violet",
   "cyan",
   "white",
   "pink",
   "lime"
  ],
  "image": [
   "https://picsum.photos/id/62/800/600",
   "https://picsum.photos/id/63/800/600",
   "https://picsum.photos/id/64/800/600",
   "https://picsum.photos/id/65/800/600"
  ],
  "itemId": "16",
  "categoryId": "1"
 },
 {
  "createdAt": "2022-10-28T11:26:38.955Z",
  "productId": "8c8592ef-24dc-4a29-b660-b9018a0c6295",
  "itemName": "Refined Plastic Fish",
  "itemBrief": "New ABC 13 9370, 13.3, 5th Gen CoreA5-8250U, 8GB RAM, 256GB SSD, power UHD Graphics, OS 10 Home, OS Office A & J 2016",
  "itemFull": "Ullam maiores adipisci quibusdam exercitationem placeat sapiente. Ex cupiditate et aut provident esse omnis vitae. Omnis voluptas delectus perferendis accusamus aut tempore et provident. Maxime minima ut odio exercitationem illo provident dolor mollitia dicta. Voluptatum quia rem dolorem suscipit aut. Quas perspiciatis porro quaerat.\nVoluptatem odio velit. Odio esse repellendus enim facilis temporibus in iure. Illum ipsa odio ea corrupti est ducimus fugit. Dolorum aliquid iure aut.\nEt dignissimos aperiam. Maiores dolores recusandae. Cumque maiores minima quaerat perspiciatis eveniet illum itaque quasi. Consectetur error dolor autem. Quia iusto id vero voluptatem repellat mollitia officiis. Dolores qui perspiciatis optio fugit omnis explicabo.",
  "price": "106.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "silver",
   "black",
   "white",
   "salmon",
   "ivory"
  ],
  "image": [
   "https://picsum.photos/id/66/800/600",
   "https://picsum.photos/id/67/800/600",
   "https://picsum.photos/id/68/800/600",
   "https://picsum.photos/id/69/800/600"
  ],
  "itemId": "17",
  "categoryId": "2"
 },
 {
  "createdAt": "2022-10-28T00:33:50.535Z",
  "productId": "f84d1193-77a5-43a2-bd58-5cc1def2a34d",
  "itemName": "Generic Cotton Table",
  "itemBrief": "The automobile layout consists of a front-engine design, with transaxle-type transmissions mounted at the rear of the engine and four wheel drive",
  "itemFull": "Voluptatem nulla perspiciatis ut. Molestias magnam sit porro inventore. Temporibus sunt omnis impedit rerum sequi perspiciatis ut ut expedita.\nEsse ipsa amet soluta neque. Alias similique quo id tempora quis molestiae ut aliquid neque. Voluptas eveniet fuga provident ea earum in delectus rerum ea. Ea sint sequi amet temporibus deleniti quia velit.\nDolor odit cupiditate quasi tempora hic pariatur. Omnis commodi quo. Animi sunt est laboriosam.",
  "price": "834.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "mint green",
   "silver",
   "pink",
   "tan",
   "pink"
  ],
  "image": [
   "https://picsum.photos/id/70/800/600",
   "https://picsum.photos/id/71/800/600",
   "https://picsum.photos/id/72/800/600",
   "https://picsum.photos/id/73/800/600"
  ],
  "itemId": "18",
  "categoryId": "3"
 },
 {
  "createdAt": "2022-10-28T17:26:53.997Z",
  "productId": "bcc5e56c-5747-430f-946d-ee38c4785152",
  "itemName": "Handcrafted Plastic Pants",
  "itemBrief": "The beautiful range of Apple Naturalé that has an exciting mix of natural ingredients. With the Goodness of 100% Natural Ingredients",
  "itemFull": "Aut id quia laudantium. Veritatis sed et aut qui. Provident culpa quaerat eligendi enim modi nisi.\nAutem similique aspernatur. Aperiam et est delectus perspiciatis iusto. Dolorum odio iusto illo eaque et doloribus aut porro sed. Ratione consequatur numquam sunt. In voluptas dolore odio. Perspiciatis expedita voluptatem voluptatum corporis aliquam dicta aut.\nOptio et ea. Nam consequuntur modi ipsum quasi qui non ut cum voluptas. Cum quibusdam nam.",
  "price": "628.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "silver",
   "ivory",
   "ivory",
   "white",
   "olive"
  ],
  "image": [
   "https://picsum.photos/id/74/800/600",
   "https://picsum.photos/id/75/800/600",
   "https://picsum.photos/id/76/800/600",
   "https://picsum.photos/id/77/800/600"
  ],
  "itemId": "19",
  "categoryId": "4"
 },
 {
  "createdAt": "2022-10-28T16:18:41.207Z",
  "productId": "2c8e67ca-970a-4192-9250-9c48e45286d6",
  "itemName": "Small Bronze Tuna",
  "itemBrief": "Ergonomic executive chair upholstered in bonded black leather and PVC padded seat and back for all-day comfort and support",
  "itemFull": "Ut sapiente qui ut doloremque corrupti qui quos voluptatem eos. Voluptatem labore eveniet labore odit recusandae eligendi. Quo sit itaque vel unde dolores. Debitis autem ducimus ut aliquid quidem quibusdam eos ad qui. Amet nesciunt explicabo optio laborum.\nDeserunt in enim in quia. Qui esse laudantium iusto nostrum modi doloremque expedita. Cupiditate consectetur qui a et laborum. Pariatur voluptas ipsum eaque quisquam corrupti hic earum ipsam. Quo est in commodi a. Ut magnam deleniti harum et quas.\nVoluptatibus maiores quas in sapiente molestiae consequuntur id sequi. Nulla omnis minima. Totam et dicta maiores. Eaque unde eaque laboriosam. Voluptates omnis veritatis ratione magni delectus modi nulla est.",
  "price": "22.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "orchid",
   "green",
   "grey",
   "sky blue",
   "violet"
  ],
  "image": [
   "https://picsum.photos/id/78/800/600",
   "https://picsum.photos/id/79/800/600",
   "https://picsum.photos/id/80/800/600",
   "https://picsum.photos/id/81/800/600"
  ],
  "itemId": "20",
  "categoryId": "5"
 },
 {
  "createdAt": "2022-10-28T06:45:53.543Z",
  "productId": "3debbc94-8376-46e5-b4de-e3e111504714",
  "itemName": "Rustic Concrete Ball",
  "itemBrief": "The Nagasaki Lander is the trademarked name of several series of Nagasaki sport bikes, that started with the 1984 ABC800J",
  "itemFull": "Qui reprehenderit magnam laboriosam iure distinctio dolore. Nulla quas voluptatem veniam reprehenderit ad ducimus quia natus. Modi corrupti dolor perferendis. Dolores est atque nemo quis voluptates ea. Id nobis ea. Est eos eligendi aperiam eos sed placeat sint et.\nUllam et impedit neque magni recusandae architecto numquam et autem. Quidem voluptatem cumque consequatur. Sunt labore et quae. Dolores qui maxime cupiditate aut placeat dolor. Aliquid porro commodi explicabo id soluta consequuntur vero. Aperiam itaque enim eius ut expedita laborum maxime.\nEveniet nobis excepturi libero aut ipsa nihil earum. Aut quod illo magni consectetur inventore in perferendis ad. Qui distinctio et placeat. Molestiae cum deleniti facere architecto. Impedit perspiciatis et est excepturi. Facilis rerum dolorum quae odit optio ut tempore.",
  "price": "252.00",
  "size": [
   "M",
   "L",
   "XL"
  ],
  "colors": [
   "magenta",
   "silver",
   "yellow",
   "plum",
   "orchid"
  ],
  "image": [
   "https://picsum.photos/id/82/800/600",
   "https://picsum.photos/id/83/800/600",
   "https://picsum.photos/id/84/800/600",
   "https://picsum.photos/id/85/800/600"
  ],
  "itemId": "21",
  "categoryId": "1"
 },
 {
  "createdAt": "2022-10-28T15:35:24.262Z",
  "productId": "6fcd9618-3194-4c2c-93b3-e8b44e41c21b",
  "itemName": "Gorgeous Soft Sausages",
  "itemBrief": "New range of formal shirts are designed keeping you in mind. With fits and styling that will make you stand apart",
  "itemFull": "Accusamus nisi et praesentium. Est voluptatem culpa. Sed dolorum est voluptas ducimus adipisci enim. Ut aspernatur sit ut ut omnis nesciunt. Quam quasi tempora libero quas inventore voluptatibus eligendi.\nAutem ut voluptatem fugiat recusandae. Tempore molestias adipisci cupiditate optio corrupti. Alias aut et quisquam itaque accusamus quia optio numquam. Voluptatem voluptatem explicabo itaque et ut accusamus. Non suscipit nisi. Voluptatum aut sapiente consequatur non numquam quia.\nArchitecto sunt temporibus sit deleniti est autem laudantium. Maxime iure et veritatis. Quis enim voluptatem ea aut quis voluptas error voluptatem.",
  "price": "522.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "white",
   "sky blue",
   "orange",
   "maroon",
   "pink"
  ],
  "image": [
   "https://picsum.photos/id/860/800/600",
   "https://picsum.photos/id/87/800/600",
   "https://picsum.photos/id/88/800/600",
   "https://picsum.photos/id/89/800/600"
  ],
  "itemId": "22",
  "categoryId": "2"
 },
 {
  "createdAt": "2022-10-28T10:13:16.647Z",
  "productId": "f81aca08-a7e6-4517-96c2-3c42fb8dcc1a",
  "itemName": "Sleek Frozen Mouse",
  "itemBrief": "The Football Is Good For Training And Recreational Purposes",
  "itemFull": "Iure at ut minus aut quas ipsum voluptas. Sequi porro reprehenderit. Eum ab quas. Labore similique reprehenderit sint totam. Natus qui mollitia.\nPlaceat sit vitae autem qui. Modi aliquam nam quam voluptatem. A quia velit vitae iste aspernatur et ratione. Aut qui et quod quibusdam dolorem.\nIure cumque necessitatibus eos autem numquam maiores dicta provident perferendis. Explicabo et ad error non nam aliquid aspernatur a. Et consectetur dicta sint cumque dicta. Aut sunt vel.",
  "price": "256.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "olive",
   "sky blue",
   "lavender",
   "red",
   "magenta"
  ],
  "image": [
   "https://picsum.photos/id/90/800/600",
   "https://picsum.photos/id/91/800/600",
   "https://picsum.photos/id/92/800/600",
   "https://picsum.photos/id/93/800/600"
  ],
  "itemId": "23",
  "categoryId": "3"
 },
 {
  "createdAt": "2022-10-28T09:31:20.504Z",
  "productId": "523c2f8c-3ba7-4b34-9647-aa7282fa3684",
  "itemName": "Awesome Steel Bacon",
  "itemBrief": "Ergonomic executive chair upholstered in bonded black leather and PVC padded seat and back for all-day comfort and support",
  "itemFull": "Architecto sapiente in voluptas et. Est laudantium aliquam quis voluptas nesciunt aspernatur sint. Voluptas repellat dolorem nihil qui repellendus.\nQui aut qui deleniti et repudiandae. Ab dolore aut sint voluptatem et quia sapiente eum consequatur. Dolores voluptas tempore sed sit aut mollitia et optio maiores. Dicta est nisi vitae nostrum non commodi incidunt est dicta. Quam debitis nulla vel sed sed sed eum. Eum dolorem molestiae labore.\nRepudiandae aspernatur fugit alias non eligendi aut. Rerum provident omnis autem iusto modi quis quis. Est quis vel explicabo voluptatem quod et.",
  "price": "451.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "orchid",
   "mint green",
   "mint green",
   "maroon",
   "ivory"
  ],
  "image": [
   "https://picsum.photos/id/94/800/600",
   "https://picsum.photos/id/95/800/600",
   "https://picsum.photos/id/96/800/600",
   "https://picsum.photos/id/97/800/600"
  ],
  "itemId": "24",
  "categoryId": "4"
 },
 {
  "createdAt": "2022-10-28T13:24:58.611Z",
  "productId": "c01e3aa0-ed8e-4547-82a6-36a1c97cba2b",
  "itemName": "Generic Granite Towels",
  "itemBrief": "The beautiful range of Apple Naturalé that has an exciting mix of natural ingredients. With the Goodness of 100% Natural Ingredients",
  "itemFull": "Harum rerum quis a laboriosam unde. Voluptatum laboriosam laudantium molestiae quidem hic. Quod expedita culpa excepturi cupiditate earum veritatis. Autem vero earum in et et.\nSint facere ipsa. Facilis aperiam blanditiis. Rerum ullam quia officiis reiciendis rerum. Quo harum sapiente soluta labore sunt qui vel. Dolorem qui sit rem vitae adipisci et.\nUnde aliquid et ipsa. Qui explicabo ut quia facilis eaque qui impedit laboriosam. Ea consequatur ullam sit dicta. Architecto perferendis corporis doloribus excepturi qui. Tenetur fugit libero. Qui libero ad eos recusandae et aspernatur.",
  "price": "805.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "orange",
   "purple",
   "violet",
   "maroon",
   "white"
  ],
  "image": [
   "https://picsum.photos/id/98/800/600",
   "https://picsum.photos/id/99/800/600",
   "https://picsum.photos/id/100/800/600",
   "https://picsum.photos/id/101/800/600"
  ],
  "itemId": "25",
  "categoryId": "5"
 },
 {
  "createdAt": "2022-10-28T16:15:19.342Z",
  "productId": "f4edebac-0a40-4e32-a5d5-eb9a0621848e",
  "itemName": "Refined Bronze Cheese",
  "itemBrief": "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit",
  "itemFull": "Sed illo doloribus iste vitae in itaque. Eligendi eos expedita voluptas aspernatur doloremque minus minus. Maxime delectus ea aut repellat nihil. Recusandae quidem at sapiente est omnis. Laborum harum adipisci ut consequuntur voluptas cupiditate et ullam.\nMinus nam consectetur et ducimus culpa et sunt sint. Error aspernatur qui nihil voluptatem laudantium et id aut. Doloremque veritatis temporibus qui laudantium dolores quia.\nPossimus enim et. Nam repellat et quo est totam labore deserunt excepturi sed. Deleniti quis quisquam quibusdam in. Voluptas enim culpa eum tenetur at accusamus omnis natus. Dolorem quos eveniet totam voluptates sed hic et nisi.",
  "price": "65.00",
  "size": [
   "S",
   "M",
   "L",
   "XL"
  ],
  "colors": [
   "maroon",
   "maroon",
   "grey",
   "magenta",
   "grey"
  ],
  "image": [
   "https://picsum.photos/id/102/800/600",
   "https://picsum.photos/id/501/800/600",
   "https://picsum.photos/id/104/800/600",
   "https://picsum.photos/id/105/800/600"
  ],
  "itemId": "26",
  "categoryId": "1"
 },
 {
  "createdAt": "2022-10-28T09:22:58.350Z",
  "productId": "64bbedb2-3fb3-45ad-bd27-4d12c2910c98",
  "itemName": "Handmade Wooden Table",
  "itemBrief": "The automobile layout consists of a front-engine design, with transaxle-type transmissions mounted at the rear of the engine and four wheel drive",
  "itemFull": "Est ut quia ut qui possimus adipisci labore. Aut accusamus velit. Non id architecto dolor ratione suscipit porro sunt. Adipisci repellendus minus et ullam ducimus. Alias atque quo consequatur.\nDolorem alias accusantium eligendi eius ratione illo blanditiis modi aut. Quidem illo quasi deleniti tempora beatae veritatis amet voluptas. Ipsam ullam ab earum quis. Aspernatur corporis quos eligendi voluptas. Ipsa et vel tempora.\nAtque similique et autem odio id et. Non nulla autem quia aut est rerum inventore. Repellendus et cum exercitationem.",
  "price": "99.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "pink",
   "pink",
   "turquoise",
   "lavender",
   "turquoise"
  ],
  "image": [
   "https://picsum.photos/id/106/800/600",
   "https://picsum.photos/id/107/800/600",
   "https://picsum.photos/id/108/800/600",
   "https://picsum.photos/id/109/800/600"
  ],
  "itemId": "27",
  "categoryId": "2"
 },
 {
  "createdAt": "2022-10-28T09:22:06.922Z",
  "productId": "a0341b6e-95ef-4317-869c-62f5df839ffa",
  "itemName": "Awesome Rubber Pizza",
  "itemBrief": "Boston's most advanced compression wear technology increases muscle oxygenation, stabilizes active muscles",
  "itemFull": "Neque facere doloremque eum odio adipisci ipsum. Sit numquam doloribus magni quis. Sint ut voluptatum quaerat adipisci consequuntur voluptate temporibus ea et.\nFacilis quasi aut non. Ducimus quis consequatur enim quae nostrum maiores eaque. Similique nihil in ducimus.\nNisi ab hic numquam eligendi ad praesentium eum. Est sed est voluptas laudantium consequuntur aut. Illo ratione pariatur sunt vel et aspernatur aut impedit ut. Quis excepturi vel recusandae aspernatur aliquam enim accusamus consequatur. Modi ad ut voluptate dolorum ea perferendis in quisquam optio.",
  "price": "178.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "indigo",
   "black",
   "grey",
   "salmon",
   "fuchsia"
  ],
  "image": [
   "https://picsum.photos/id/110/800/600",
   "https://picsum.photos/id/111/800/600",
   "https://picsum.photos/id/112/800/600",
   "https://picsum.photos/id/113/800/600"
  ],
  "itemId": "28",
  "categoryId": "3"
 },
 {
  "createdAt": "2022-10-28T11:55:25.503Z",
  "productId": "d565ac04-b92b-416f-a30f-012818893643",
  "itemName": "Unbranded Steel Tuna",
  "itemBrief": "The beautiful range of Apple Naturalé that has an exciting mix of natural ingredients. With the Goodness of 100% Natural Ingredients",
  "itemFull": "Et quia corrupti officia nihil et tempora. Aut odit voluptatem dolores quaerat autem aut voluptatem voluptas. Nihil suscipit aut cupiditate omnis facilis iure dicta. Ullam odit animi odit temporibus consequatur quia consequatur consequatur molestiae.\nEum ea aliquam nihil id. Animi magni qui reiciendis blanditiis omnis. Expedita accusamus aliquid.\nNobis aut aliquam aut ratione est dolor nostrum asperiores aut. Dignissimos aliquam eligendi facere. Ut fugiat laborum ut molestiae explicabo molestias labore. Mollitia repellendus quisquam maiores autem eligendi non nulla. Sunt dicta voluptates voluptatem. Dolorum et rem explicabo culpa facilis.",
  "price": "793.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "mint green",
   "orange",
   "salmon",
   "orchid",
   "violet"
  ],
  "image": [
   "https://picsum.photos/id/114/800/600",
   "https://picsum.photos/id/115/800/600",
   "https://picsum.photos/id/116/800/600",
   "https://picsum.photos/id/117/800/600"
  ],
  "itemId": "29",
  "categoryId": "4"
 },
 {
  "createdAt": "2022-10-28T13:32:08.726Z",
  "productId": "83be6aa9-2b83-44e1-99df-ad017dad04d0",
  "itemName": "Oriental Granite Bike",
  "itemBrief": "Carbonite web goalkeeper gloves are ergonomically designed to give easy fit",
  "itemFull": "Perferendis deleniti ut facere et. Temporibus accusantium fuga. Quas ipsa et qui neque. Aut nobis optio eum debitis quia.\nCum blanditiis tempore illo aut deleniti est et hic. A est et autem quam. Vitae modi eaque esse sunt. Amet dolore illo est corporis. Quo dicta et eligendi ut non saepe provident. Facilis hic nemo atque porro laborum iste ut.\nEt sequi occaecati libero laborum dolor. At eius molestias. Cumque sit aut voluptas earum sed doloremque sapiente repudiandae. Veniam quam qui aperiam animi eligendi amet. Quis enim animi modi magni est cupiditate expedita.",
  "price": "640.00",
  "size": [
   "S",
   "M",
   "L",
   "XL",
   "XXL"
  ],
  "colors": [
   "azure",
   "lime",
   "violet",
   "white",
   "orange"
  ],
  "image": [
   "https://picsum.photos/id/118/800/600",
   "https://picsum.photos/id/119/800/600",
   "https://picsum.photos/id/120/800/600",
   "https://picsum.photos/id/121/800/600"
  ],
  "itemId": "30",
  "categoryId": "5"
 }
];